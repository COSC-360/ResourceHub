import express from "express";
import cors from "cors";
import path from "path";
import { fileURLToPath } from "url";
import { userRoutes } from "./routes/userRoutes.js";
import { adminAnalyticsRoutes } from "./routes/adminAnalyticsRoutes.js";
import { courseRoutes } from "./routes/courseRoutes.js";
import { discussionRoutes } from "./routes/discussionRoutes.js";
import { commonRoutes } from "./routes/commonRoutes.js";
import { voteRoutes } from "./routes/voteRoutes.js";
import { membershipRoutes } from "./routes/membershipRoutes.js";
import swaggerUi from 'swagger-ui-express';
import { specs } from './swagger.js';
import notificationRoutes from "./routes/notificationRoutes.js";

const app = express();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

app.use(
  cors({
    origin: "http://localhost:5173",
    credentials: true,
  })
);
app.use((req, res, next) => {
  if (req.headers["Content-Type"]?.includes("multipart/form-data")) {
    next();
  } else {
    express.json({ limit: "10mb" })(req, res, next);
  }
});

app.use(express.json({ limit: "10mb" }));

app.use(express.urlencoded({ limit: "10mb", extended: true }));

app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(specs));

app.get("/api/health", (_req, res) => {
  res.status(200).json({ status: "ok" });
});

app.use("/api/analytics", adminAnalyticsRoutes);
app.use("/api/user", userRoutes);
app.use("/api/courses", courseRoutes);
app.use("/api/discussion", discussionRoutes);
app.use("/api/common", commonRoutes);
app.use("/api/vote", voteRoutes);
app.use("/api/memberships", membershipRoutes);
app.use("/api/notifications", notificationRoutes);

app.use("/uploads", express.static(path.resolve(__dirname, "uploads")));
app.use("/assets", express.static(path.resolve(__dirname, "assets")));

export default app;
